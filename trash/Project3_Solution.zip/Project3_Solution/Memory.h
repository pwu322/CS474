#include "Appliance.h"

class Memory
{
    public:
        void loadAppliance(int, Appliance*&);
        void saveAppliance(Appliance&);
};